import socket
import os

## UNIXソケットの作成

sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)

server_address='/tmp/socket_file' ##サーバ側が接続を待つUNIXソケットのパスを設定

##以前の接続が残っていた場合に備えてサーバアドレスを削除する
try:
    os.unlink(server_address) 
except FileNotFoundError:
    pass

print("Starting up on {}".format(server_address))

sock.bind(server_address)
sock.listen(1)##ソケットが接続要求を待機

while True:##クライアントからの接続を待ち続ける
    connection,client_address=sock.accept()##クライアントからの接続を受け入れる

    try:
        print("connection from",client_address)

        while True:
            data=connection.recv(16)#16→一度に読み込むデータの最大バイト数

            data_str=data.decode("utf-8")#受け取ったデータはバイナリ形式なのでそれを文字列に変換
            print("Received"+data_str)

            if data:
                response="Processing" + data_str
                connection.sendall(response.encode())#バイナリ形式に戻して返す
            else:
                print("No data from " + client_address)
                break
    finally:
        print("Closing current connection")
        connection.close()