import socket
import os

#AF_UNIXはUNIXドメインソケットを表し、SOCK_DGRAMはデータグラムソケットを表す
sock=socket.socket(socket.AF_UNIX,socket.SOCK_DGRAM)

server_address="/tmp/udp_socket_file"

try:
    os.unlink(server_address)
except FileNotFoundError:
    pass

print("starting up on {}".format(server_address))

##sockオブジェクトのbindメソッドを使ってソケットを特定のアドレスに紐つける
sock.bind(server_address)

while True:
    print("\nwaiting to receive message")
    data,address=sock.recvfrom(4096)#ソケットからデータを受信。4096→一度に受信できる最大バイト数

    print("received {} bytes from {}".format(len(data),address))
    print(data)

    if data:
        sent=sock.sendto(data,address)
        print("sent {} bytes back to {}".format(len(data),address))